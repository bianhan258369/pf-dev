===============================
MyCCSL v1.3.22 for windows
===============================
Open MyCCSL.exe 

The main view on the right of window is an editbox and support the formulas you input.
(1)It uses // or / something to express a code commenting.
(2)One line for each formula strictly.
(3)In general, you only write some CCSL constraints to describe a specific problem.
We have defined 12 constraints, but sometimes these maybe not enough e.g., you want to define a new constraint.
If you know SMT-LIB, you can just write a SMT-formula here to supplement your description.
(4)It uses -> CCSL constraint or => LTL formula to prove invalidity in the last line.
For the above, some simple examples written in the editbox when you open the window.

There are some options on the left, which serve the CCSL constraints in the editbox.
(1)SMT-slover: Z3 or CVC4
(2)Timeout(sec): the program will stop when it runs over this time.
(3)Bound: if it is zero, the program will be run without bound. In general, you can get nothing.
Of course, you can try the nobound condition. But, you should set a bound generally.
(4)Period: click it, the CCSL constraints you input will be build on the periodic condition.
Then, you can change the length of period if you input a number greater than zero.
(5)Check Dead Lock: click it, you can check if there exists a deadlock on the CCSL constraints.
(6)RUN: click it and start the program when you finish all setting. The result will be seen below.
In the label Symbol, you can choose the CCSL or LTL connectives to help your coding in the editbox.
In the label Functions
(1)Add Trace Path: get a trace file and run to analyze whether it satisfies the CCSL constrains.
(2)Print the Result: save the trace result you get.
(3)Draw the Result: you will get a simulation of result in the form of images.
(4)About...
On the top of window, you can save your coding and get my email.

Wish you have a fun with the tool.
12 Apr. 2017 